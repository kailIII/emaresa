# -*- encoding: utf-8 -*-
{
    'name': 'Econube Depreciacion',
    'version': '0.1',
    'depends': ['account','account_asset','account_asset_analytic'],
    'author': 'Econube | Pablo Cabezas, Jose Pinto ',
    'description': "Modulo para depreciar activos",
    'category': 'Accounting & Finance',
    'data': [
        'wizard/vista_menu.xml',
        'account_asset_category_view.xml'
    ],
    
    'auto_install': False,
    'installable': True,
    'application': False,
}