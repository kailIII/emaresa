
# -*- encoding: utf-8 -*-
#
# OpenERP Correccion Monetaria
# Copyright (C) 2011-2013 David Acevedo <dacevedo@stratanet.cl>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from osv import osv, fields
import time

class account_asset_depreciacion(osv.osv_memory):
    _name = 'account.asset.depreciacion'

    _columns = {
        'company_id':fields.many2one('res.company', 'Empresa', required=True, readonly=False),
        'period':fields.many2one('account.period', 'Periodo', help="Seleccione el Periodo Para Corregir", required=True, readonly=False),
#        'cm_categ':fields.many2one('account.account', 'Cuenta Para Correccion Monetaria', required=True, readonly=False),
        'asset_type': fields.selection([\
            ('activo_fijo', 'Activo Fijo'),\
            ('existencia', 'Existencia')],\
            'Tipo de Activo', required=True, readonly=False),
#        'cm':fields.float('Correccion Monetaria del Periodo', required=True, readonly=False),
        'state':fields.selection([('step1','step1'),('step2','step2')]),
        'accounting_type':fields.selection([('tributario','Tributario'),('ifrs','IFRS'),('usgaap','USGAAP')],\
            'Tipo Contable', required=True, readonly=False),
        'account_analytic_id': fields.many2one('account.analytic.account', 'Analytic account'),                
    }

    _defaults = {
        'state': 'step1',
        'asset_type': 'activo_fijo',
        'company_id': lambda self,cr,uid,c: self.pool.get('res.company')._company_default_get(cr, uid, 'correccion.monetaria.wizard',\
            context=c),
    }

    def calc(self, cr, uid, ids, context=None):
        ### Busco objetos
        account_asset_cm_obj = self.pool.get('correccion.monetaria')
        account_move_obj = self.pool.get('account.move')
        wizard = self.browse(cr, uid, ids)[0]
        asset = self.pool.get('account.asset.asset')
        dep = self.pool.get('account.asset.depreciation.line')
#        journal_id = self.pool.get('account.journal').search(cr, uid, [('code','=','750')])[0]
        journal_id = self.pool.get('account.journal').search(cr, uid, [('code','=','601')])[0]
        #Tomo el periodo de la depreciacion y lo convierto en fecha
        month, year = wizard.period.code.split('/')
        date = year+'-'+month+'-01'
        if month == '00':
            raise osv.except_osv(('Error!'), ("Debe elegir un periodo valido para la correccion monetaria"))
        cm = 1
        categs = {}
        account_dict = {}
        vals = []
        vals_cm = []
        acum_activo = 0
        acum_dep = 0
        #asset_obj_categ = self.pool.get('account.asset.category').search(cr, uid, [('accounting_type','=','tributario')]) # Version legal
        # Busco las categorias de activos que sean del tipo TRIBUTARIO                
        asset_obj_categ_ids = self.pool.get('account.asset.category').search(cr, uid, [('accounting_type','=',wizard['accounting_type'])])
        #asset_obj_categ_ids = self.pool.get('account.asset.category').search(cr, uid, [('x_tipo','=','TRIBUTARIO')])
        if wizard['account_analytic_id']:
            print wizard['account_analytic_id']
            account_analytic_id = wizard['account_analytic_id']['id']
            asset_obj_ids = asset.search(cr, uid,[('category_id','in',asset_obj_categ_ids),('state','=','open'),('account_analytic_id','=',account_analytic_id)])
            if len(asset_obj_ids) <= 0:
                raise osv.except_osv(('Error!'), ("No se Encontraron Activos para esa categoria y esa cuenta analitica"))
        else:
            asset_obj_ids = asset.search(cr, uid,[('category_id','in',asset_obj_categ_ids),('state','=','open')])
        # Busco objetos de activos buscados anteriormente
        asset_obj = asset.browse(cr, uid, asset_obj_ids)
        # Busco los ids de las lineas de depreciacion no asentadas y con referencia a los activos fijos buscados ateriormente
        asset_all_dep_obj_ids = dep.search(cr, uid,[('asset_id','in',asset_obj_ids),('move_check','=',False)])
        for asset_categ_obj in asset_obj:
            if not categs.has_key(asset_categ_obj.category_id.name):
                categs[asset_categ_obj.category_id.name[5:]] = 0
                categs['DEP ACUMULADA '+asset_categ_obj.category_id.name[5:]] = 0
        # Recorro activos para tomar valores
        for a_obj in asset_obj:
            purchase_value = a_obj.purchase_value * (1)
            # Busco los ids de las lineas de depreciacion no asentadas y con referencia al activo fijo tomado anteriormente con
            # fecha superior a la del periodo
            asset_dep_obj_ids = dep.search(cr, uid,[('asset_id','=',a_obj.id),('move_check','=',False),\
                ('depreciation_date','>=',date)])
            
            if len(asset_dep_obj_ids) > 0:
                # Ordeno los ids para poder llamarlos espero en orden de menor a mayor luego en los objetos xD
                asset_dep_obj_ids.sort()
                # Busco objetos de lineas de depreciacion no asentadas y pertenecientes al activo fijos tomado anteriormente
                asset_dep_obj = dep.browse(cr, uid, asset_dep_obj_ids)
                asset_name_cond = True
                for dep_obj in asset_dep_obj:
                    if dep_obj.depreciation_date == date:
                        escribe_activo = True
                        realizar = True
                        break
                    else:
                        escribe_activo = False
                        realizar = False
                if realizar:
                    # Recorro lineas de depreciacion de activos para tomar valores
                    for dep_obj in asset_dep_obj:
                        if asset_name_cond:
                            key_name_dep = 'DEP ACUMULADA '+dep_obj.asset_id.category_id.name[5:]
                            # Obtiene el valor acumulado de la depreciacion por categoria
                            categs[key_name_dep] += dep_obj.depreciated_value * 1
                            account_dict[key_name_dep+' ACCOUNT DEPRECIATION'] = dep_obj.asset_id.category_id.account_depreciation_id.id
                            amount = dep_obj.amount * (1)
                            depreciated_value = dep_obj.depreciated_value * (1)
                            asset_name_cond = False
                        else:
                            depreciated_value += amount
        
                        remaining_value = purchase_value - a_obj.salvage_value - depreciated_value - amount    
                        # Escribo el nuevo valor de la linea de depreciacion del activo corregida 
                        dep.write(cr, uid, [dep_obj.id], {
                            'amount': amount,
                            'depreciated_value': depreciated_value,
                            'remaining_value': remaining_value
                        })
                        # Creacion valores tabla propia para asientos, en caso de ser la linea del periodo
                        
                        if dep_obj.depreciation_date == date:
                            '''
                            account_asset_cm_obj.create(cr, uid, {
                                'name': str(dep_obj.asset_id.code)+"|"+str(dep_obj.name),
                                'asset_asset_id': dep_obj.asset_id.id,
                                'asset_dep_id': dep_obj.id,
                                'valor_cm_af': purchase_value,
                                'valor_cm_dep': depreciated_value,
                                'periodo': wizard.period.code,
                                'company_id': wizard.company_id.id,
                            })
                            '''
                            dep.create_move(cr, uid, [dep_obj.id])
                            
            else:
                escribe_activo = False        
            
            if escribe_activo:
                #Tomo el nombre del diccionario para el activo
                key_name_asset = a_obj.category_id.name[5:]
                # asigno los valores de las lineas del asiento de correccion monetaria realizados por categoria
                categs[key_name_asset] += a_obj.purchase_value * cm    
                account_dict[key_name_asset+' ACCOUNT ASSET'] = a_obj.category_id.account_asset_id.id    
                # Escribo el nuevo valor del activo corregido 
                asset.write(cr, uid, [a_obj.id], {
                    'purchase_value': purchase_value
                })
                
# Creacion de linea de asiento debe
        for key in categs.keys():
            if key[:13] == 'DEP ACUMULADA' and categs[key] != 0:
                diccionario = {
                    'name': key,
                    'date': time.strftime('%Y-%m-%d'),
                    'credit': categs[key],
                    'debit': 0,
                    'account_id': account_dict[key+' ACCOUNT DEPRECIATION'],
                }
                vals.append((0, 0, diccionario))
                # Valor de la linea de depresiacion acumulada asiento de activos
                acum_dep += categs[key]
            
            elif key[:13] != 'DEP ACUMULADA' and categs[key] != 0:
                vals.append((0, 0, {
                    'name': key,
                    'date': time.strftime('%Y-%m-%d'),
                    'credit': 0,
                    'debit': categs[key],
                    'account_id': account_dict[key+' ACCOUNT ASSET'],
                }))
                # Valor de la linea de depresiacion acumulada asiento de activos
                acum_activo += categs[key]        
       
        self.write(cr, uid, ids, {'state': 'step2'}, context=context)
        return True
account_asset_depreciacion()

'''    
        vals.append((0, 0, {
            'name': 'CORRECCION MONETARIA',
            'date': time.strftime('%Y-%m-%d'),
            'credit': acum_activo - acum_dep,
            'debit': 0,
            'account_id': wizard.cm_categ.id,
        }))
'''            
# Creacion de asiento Categorias de activos contra depreciacion acumulada por categorias #750 journal_id
'''
        account_move_obj.create(cr, uid, {
            'name': 'CM Activo Fijo del Periodo '+wizard.period.name,
            'journal_id': journal_id,
            'period_id': wizard.period.id,
            'ref': 'CM Activo Fijo del Periodo '+wizard.period.name,
            'company_id': wizard.company_id.id,
            'line_id': vals,
        })
'''